public class ExibeValores{

  public static void main(String[] args)  {
        
    short dois = 19;
    
    int tres = 1571;
    
    long seis = 100000;
    
    float quatro = 2147483648f;
    
    double muitos = 3.141592653589793;
    
    boolean valor = true;
    
    String nome = "K";
    
    System.out.println(dois);
    System.out.println(tres);
    System.out.println(seis);
    System.out.println(quatro);
    System.out.println(muitos);
    System.out.println(valor);
    System.out.println(nome);

    
  }
}

