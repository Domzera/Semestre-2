public class GerenciamentoLoja{

  public static void main(String[] args){
    
    int numeroPedido = 001;
    String codigoProduto = "Heinken 660ml";
    int quantidade = 12;
    double  valorTotal= 98.6;

    System.out.println("O numero do pedido eh: "+numeroPedido);
    System.out.println("O codigo do produto eh: "+codigoProduto);
    System.out.println("A quantidade eh: "+quantidade);
    System.out.println("O valor da compra eh: "+valorTotal);
    
  }
}
