public class ExibeIdade{

  public static void main(String[] args)  {
    
    int idade = 40;
    
    System.out.println("Minha idade é "+idade);
    System.out.printf("Minha idade é %d\n",idade);
    

    
  }
}

