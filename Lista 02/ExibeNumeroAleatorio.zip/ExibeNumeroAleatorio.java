import java.util.Random;

public class ExibeNumeroAleatorio{

  public static void main(String[] args)  {
        
    double var = Math.random();
    
    System.out.println(var);  

    
  }
}

