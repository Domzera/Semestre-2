public class TestaVariavelPeso{

  public static void main(String[] args){
    
    double peso = 98.6;

    System.out.println("Meu peso eh: "+peso+" Kg.");
    System.out.printf("Meu peso eh: %.3f kg.",peso);
  }
}
