public class ExibeNome{

  public static void main(String[] args)  {
        
    String nome = "\"Luiz Celio gomes filho\"";
    
    System.out.println(nome);  

    
  }
}

