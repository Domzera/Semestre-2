public class CopiaValores
{

  public static void main(String[] args)
  {
    float numero = 3.14f;
    float numeroCopia = numero;

    System.out.print("Numero = "+numero+" /Numero copia = "+numeroCopia);
  }
}
