public class ValorNull{

  public static void main(String[] args)
  {
    Double numero = 3.14d;
    
    System.out.print("Numero = "+numero);
    
    numero = null;
    
    System.out.print("Numero vazio = ");
  }
}
