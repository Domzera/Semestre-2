public class DuasMensagens{

  public static void main(String[] args)  {
    
    System.out.println("Hello World 1");
    System.out.print("Hello World 2");
  }
}

