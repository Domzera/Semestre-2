public class Cursos{

  public static void main(String[] args)  {
    
    System.out.printf("F01\n\tLogica de programacao\nF02\n\tLinguagem de Programacao\nF03\n\tProgramacao Orientada a Objetos");
  }
}

