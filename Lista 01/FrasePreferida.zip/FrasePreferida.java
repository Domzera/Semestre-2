public class FrasePreferida{

  public static void main(String[] args)  {
    
    System.out.println("Para acabar com uma guerra basta não entrar nela");
    
  }
}

