public class Triangulo{
  
  public static void main(String[] args){
    
    System.out.printf("*\n**\n***\n****\n*****");
  }
}